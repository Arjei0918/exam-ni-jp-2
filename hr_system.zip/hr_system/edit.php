
<?php
require_once "db.php";

function e($value) {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        "UTF-8"
    );
}

$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    http_response_code(400);
    exit("Invalid employee ID.");
}

$stmt = $pdo->prepare(
    "SELECT * FROM employees WHERE id = :id"
);
$stmt->execute([":id" => $id]);

$employee = $stmt->fetch();

if (!$employee) {
    http_response_code(404);
    exit("Employee not found.");
}

$employee_code = $employee["employee_code"];
$full_name = $employee["full_name"];
$department = $employee["department"];
$salary = $employee["salary"];
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $employee_code = trim($_POST["employee_code"] ?? "");
    $full_name = trim($_POST["full_name"] ?? "");
    $department = trim($_POST["department"] ?? "");
    $salary = trim($_POST["salary"] ?? "");

    if (
        $employee_code === "" ||
        $full_name === "" ||
        $department === "" ||
        $salary === ""
    ) {
        $error = "All fields are required.";
    } elseif (
        !is_numeric($salary) ||
        (float)$salary < 0 ||
        (float)$salary >= 100000000
    ) {
        $error = "Enter a valid salary.";
    } else {
        try {
            $sql = "UPDATE employees
                    SET employee_code = :emp_code,
                        full_name = :full_name,
                        department = :department,
                        salary = :salary
                    WHERE id = :id";

            $stmt = $pdo->prepare($sql);

            $stmt->execute([
                ":emp_code" => $employee_code,
                ":full_name" => $full_name,
                ":department" => $department,
                ":salary" => $salary,
                ":id" => $id
            ]);

            header("Location: index.php");
            exit;

        } catch (PDOException $ex) {
            error_log($ex->getMessage());

            if ($ex->getCode() === "23000") {
                $error = "Employee code already exists.";
            } else {
                $error = "Unable to update employee record.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Employee</title>
</head>
<body>

<h2>Edit Employee</h2>

<?php if ($error !== ""): ?>
    <p style="color:red;"><?= e($error) ?></p>
<?php endif; ?>

<form method="POST">
    <label>Employee Code:</label><br>
    <input type="text" name="employee_code"
           maxlength="50"
           value="<?= e($employee_code) ?>" required>
    <br><br>

    <label>Full Name:</label><br>
    <input type="text" name="full_name"
           maxlength="100"
           value="<?= e($full_name) ?>" required>
    <br><br>

    <label>Department:</label><br>
    <input type="text" name="department"
           maxlength="100"
           value="<?= e($department) ?>" required>
    <br><br>

    <label>Salary:</label><br>
    <input type="number" name="salary"
           min="0" max="99999999.99"
           step="0.01"
           value="<?= e($salary) ?>" required>
    <br><br>

    <button type="submit">Update Employee</button>
    <a href="index.php">Cancel</a>
</form>

</body>
</html>
