
<?php
require_once "db.php";

$employee_code = "";
$full_name = "";
$department = "";
$salary = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $employee_code = trim($_POST["employee_code"] ?? "");
    $full_name = trim($_POST["full_name"] ?? "");
    $department = trim($_POST["department"] ?? "");
    $salary = trim($_POST["salary"] ?? "");

    if (
        $employee_code === "" ||
        $full_name === "" ||
        $department === "" ||
        $salary === ""
    ) {
        $error = "All fields are required.";
    } elseif (
        !is_numeric($salary) ||
        (float)$salary < 0 ||
        (float)$salary >= 100000000
    ) {
        $error = "Enter a valid salary.";
    } else {
        try {
            $sql = "INSERT INTO employees
                    (employee_code, full_name, department, salary)
                    VALUES
                    (:emp_code, :full_name, :department, :salary)";

            $stmt = $pdo->prepare($sql);

            $stmt->execute([
                ":emp_code" => $employee_code,
                ":full_name" => $full_name,
                ":department" => $department,
                ":salary" => $salary
            ]);

            header("Location: index.php");
            exit;

        } catch (PDOException $e) {
            error_log($e->getMessage());

            if ($e->getCode() === "23000") {
                $error = "Employee code already exists.";
            } else {
                $error = "Unable to save employee record.";
            }
        }
    }
}

function e($value) {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        "UTF-8"
    );
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Employee</title>
</head>

<body>

<h2>Add New Employee</h2>

<?php if ($error !== ""): ?>
    <p style="color:red;">
        <?= e($error) ?>
    </p>
<?php endif; ?>

<form method="POST">

    <label>Employee Code:</label><br>
    <input type="text" name="employee_code"
           maxlength="50"
           value="<?= e($employee_code) ?>" required>
    <br><br>

    <label>Full Name:</label><br>
    <input type="text" name="full_name"
           maxlength="100"
           value="<?= e($full_name) ?>" required>
    <br><br>

    <label>Department:</label><br>
    <input type="text" name="department"
           maxlength="100"
           value="<?= e($department) ?>" required>
    <br><br>

    <label>Salary:</label><br>
    <input type="number" name="salary"
           min="0" max="99999999.99"
           step="0.01"
           value="<?= e($salary) ?>" required>
    <br><br>

    <button type="submit">Save Employee</button>
    <a href="index.php">Cancel</a>

</form>

</body>
</html>
