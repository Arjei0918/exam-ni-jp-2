
<?php
require_once "db.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    exit("Method not allowed.");
}

$id = filter_input(INPUT_POST, "id", FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    http_response_code(400);
    exit("Invalid employee ID.");
}

$stmt = $pdo->prepare(
    "DELETE FROM employees WHERE id = :id"
);

$stmt->execute([":id" => $id]);

header("Location: index.php");
exit;
?>
