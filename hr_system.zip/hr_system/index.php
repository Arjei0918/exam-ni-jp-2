
<?php
require_once "db.php";

try {
    $stmt = $pdo->query(
        "SELECT * FROM employees ORDER BY id DESC"
    );

    $employees = $stmt->fetchAll();

} catch (PDOException $e) {
    error_log($e->getMessage());
    exit("Unable to retrieve employee records.");
}

function e($value) {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        "UTF-8"
    );
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Employee Records Management</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            background: #f4f6f9;
        }

        h2 {
            text-align: center;
        }

        .add-button {
            display: inline-block;
            padding: 10px 15px;
            background: #1877c9;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
        }

        th {
            background: #e5edf5;
        }

        .edit {
            color: #087b37;
        }

        .delete-button {
            background: #c62828;
            color: white;
            border: none;
            padding: 6px 10px;
            border-radius: 4px;
            cursor: pointer;
        }

        .table-container {
            overflow-x: auto;
        }
    </style>
</head>

<body>

<h2>Employee Records Management System</h2>

<a class="add-button" href="create.php">
    Add New Employee
</a>

<div class="table-container">
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Emp Code</th>
            <th>Full Name</th>
            <th>Department</th>
            <th>Salary</th>
            <th>Actions</th>
        </tr>
    </thead>

    <tbody>
    <?php if (count($employees) > 0): ?>

        <?php foreach ($employees as $employee): ?>
        <tr>
            <td><?= (int)$employee["id"] ?></td>
            <td><?= e($employee["employee_code"]) ?></td>
            <td><?= e($employee["full_name"]) ?></td>
            <td><?= e($employee["department"]) ?></td>
            <td><?= number_format((float)$employee["salary"], 2) ?></td>

            <td>
                <a class="edit"
                   href="edit.php?id=<?= (int)$employee["id"] ?>">
                    Edit
                </a>

                |

                <form action="delete.php" method="POST"
                      style="display:inline;"
                      onsubmit="return confirm('Are you sure you want to delete this employee?');">

                    <input type="hidden" name="id"
                           value="<?= (int)$employee["id"] ?>">

                    <button type="submit" class="delete-button">
                        Delete
                    </button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>

    <?php else: ?>

        <tr>
            <td colspan="6" style="text-align:center;">
                No employee records found.
            </td>
        </tr>

    <?php endif; ?>
    </tbody>
</table>
</div>

</body>
</html>
